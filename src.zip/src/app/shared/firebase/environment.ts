export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyCAVaASCjikzai6HCRY7QolaKC0dTd7trA",
        authDomain: "sunquest-62a90.firebaseapp.com",  
        projectId: "sunquest-62a90",
        storageBucket: "sunquest-62a90.firebasestorage.app",
        messagingSenderId: "648849314151",
        appId: "1:648849314151:web:4a67c249f5e1a29cf19fc2"
    }
}