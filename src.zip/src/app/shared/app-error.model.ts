export interface AppError {
    title: string,
    message: string,
}